package com.example.funny_quotes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
